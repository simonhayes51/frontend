export interface TraderBadge {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
  earnedAt?: string;
}

export interface TraderReview {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  rating: number;
  comment: string;
  createdAt: string;
  helpful: number;
  traderId: string;
}

export interface TradeSignal {
  id: string;
  type: "buy" | "sell" | "hold";
  player: string;
  playerImage: string;
  currentPrice: number;
  targetPrice: number;
  confidence: number;
  createdAt: string;
  status: "active" | "hit" | "missed" | "expired";
  profit?: number;
}

export interface TraderStats {
  totalTrades: number;
  successfulTrades: number;
  averageProfit: number;
  bestTrade: {
    player: string;
    profit: number;
    date: string;
  };
  monthlyReturns: number[];
  streak: number;
  totalEarnings: number;
  subscriberGrowth: number;
}

export interface Trader {
  id: string;
  name: string;
  username: string;
  avatar: string;
  coverImage?: string;
  verified: boolean;
  rating: number;
  totalReviews: number;
  subscribers: number;
  following: number;
  winRate: number;
  tier: "bronze" | "silver" | "gold" | "platinum" | "diamond";
  subscriptionPrice: number;
  isSubscribed?: boolean;
  isFollowing?: boolean;
  bio?: string;
  joinedAt: string;
  lastActive: string;
  specialties: string[];
  badges: TraderBadge[];
  stats: TraderStats;
  socialLinks?: {
    twitter?: string;
    discord?: string;
    youtube?: string;
  };
}
