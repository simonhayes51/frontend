import { MainLayout } from "@/components/layout/MainLayout";
import { Trophy, Crown, Medal, TrendingUp, Star, Users, ChevronUp, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const leaderboardData = [
  {
    rank: 1,
    previousRank: 1,
    name: "CoinMaster_FC",
    username: "coinmaster",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop",
    tier: "diamond",
    winRate: 82,
    subscribers: 12500,
    earnings: 28470,
    monthlyProfit: 1250000,
  },
  {
    rank: 2,
    previousRank: 3,
    name: "TradeMaster",
    username: "trademaster",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    tier: "diamond",
    winRate: 79,
    subscribers: 9800,
    earnings: 24200,
    monthlyProfit: 980000,
  },
  {
    rank: 3,
    previousRank: 2,
    name: "FC_Trader_Pro",
    username: "traderpro",
    avatar: "https://images.unsplash.com/photo-1599566150163-29194dcabd36?w=100&h=100&fit=crop",
    tier: "platinum",
    winRate: 76,
    subscribers: 8200,
    earnings: 18900,
    monthlyProfit: 850000,
  },
  {
    rank: 4,
    previousRank: 5,
    name: "ProfitHunter",
    username: "profithunter",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    tier: "platinum",
    winRate: 74,
    subscribers: 6700,
    earnings: 15600,
    monthlyProfit: 720000,
  },
  {
    rank: 5,
    previousRank: 4,
    name: "MarketKing",
    username: "marketking",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    tier: "gold",
    winRate: 72,
    subscribers: 5600,
    earnings: 12800,
    monthlyProfit: 680000,
  },
  {
    rank: 6,
    previousRank: 7,
    name: "CoinCollector",
    username: "coincollector",
    avatar: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=100&h=100&fit=crop",
    tier: "gold",
    winRate: 70,
    subscribers: 4200,
    earnings: 9800,
    monthlyProfit: 520000,
  },
  {
    rank: 7,
    previousRank: 6,
    name: "FC_Wizard",
    username: "fcwizard",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop",
    tier: "silver",
    winRate: 68,
    subscribers: 3400,
    earnings: 7200,
    monthlyProfit: 380000,
  },
  {
    rank: 8,
    previousRank: 9,
    name: "BudgetBeast",
    username: "budgetbeast",
    avatar: "https://images.unsplash.com/photo-1463453091185-61582044d556?w=100&h=100&fit=crop",
    tier: "silver",
    winRate: 66,
    subscribers: 2100,
    earnings: 4800,
    monthlyProfit: 290000,
  },
];

const tierStyles = {
  diamond: "from-primary to-secondary",
  platinum: "from-cyan-400 to-cyan-200",
  gold: "from-yellow-500 to-yellow-300",
  silver: "from-slate-400 to-slate-300",
};

const getRankIcon = (rank: number) => {
  if (rank === 1) return <Crown className="w-5 h-5 text-yellow-400" />;
  if (rank === 2) return <Medal className="w-5 h-5 text-slate-300" />;
  if (rank === 3) return <Medal className="w-5 h-5 text-amber-600" />;
  return <span className="text-lg font-bold text-muted-foreground">#{rank}</span>;
};

export default function Leaderboard() {
  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-full mb-4">
            <Trophy className="w-5 h-5 text-primary" />
            <span className="font-semibold gradient-text">Top Traders</span>
          </div>
          <h1 className="text-3xl font-bold text-foreground font-display mb-2">Leaderboard</h1>
          <p className="text-muted-foreground">The best performing traders this month</p>
        </div>

        {/* Top 3 Podium */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {/* 2nd Place */}
          <div className="flex flex-col items-center pt-8">
            <div className="relative mb-3">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-slate-400 to-slate-300 p-0.5">
                <img
                  src={leaderboardData[1].avatar}
                  alt={leaderboardData[1].name}
                  className="w-full h-full rounded-full object-cover border-2 border-card"
                />
              </div>
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-slate-400 rounded-full flex items-center justify-center text-xs font-bold text-primary-foreground">
                2
              </div>
            </div>
            <p className="font-semibold text-foreground text-sm text-center">{leaderboardData[1].name}</p>
            <p className="text-xs text-muted-foreground">{leaderboardData[1].winRate}% win rate</p>
            <div className="mt-2 h-24 w-full bg-gradient-to-t from-slate-500/20 to-transparent rounded-t-lg flex items-end justify-center pb-2">
              <span className="text-xl font-bold text-slate-300">2nd</span>
            </div>
          </div>

          {/* 1st Place */}
          <div className="flex flex-col items-center">
            <div className="relative mb-3">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 p-0.5 animate-glow">
                <img
                  src={leaderboardData[0].avatar}
                  alt={leaderboardData[0].name}
                  className="w-full h-full rounded-full object-cover border-2 border-card"
                />
              </div>
              <div className="absolute -top-2 left-1/2 -translate-x-1/2">
                <Crown className="w-6 h-6 text-yellow-400" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-yellow-500 rounded-full flex items-center justify-center text-sm font-bold text-primary-foreground">
                1
              </div>
            </div>
            <p className="font-bold text-foreground text-center">{leaderboardData[0].name}</p>
            <p className="text-xs text-muted-foreground">{leaderboardData[0].winRate}% win rate</p>
            <div className="mt-2 h-32 w-full bg-gradient-to-t from-yellow-500/20 to-transparent rounded-t-lg flex items-end justify-center pb-2">
              <span className="text-2xl font-bold gradient-text">1st</span>
            </div>
          </div>

          {/* 3rd Place */}
          <div className="flex flex-col items-center pt-12">
            <div className="relative mb-3">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-amber-600 to-amber-400 p-0.5">
                <img
                  src={leaderboardData[2].avatar}
                  alt={leaderboardData[2].name}
                  className="w-full h-full rounded-full object-cover border-2 border-card"
                />
              </div>
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-amber-600 rounded-full flex items-center justify-center text-[10px] font-bold text-primary-foreground">
                3
              </div>
            </div>
            <p className="font-semibold text-foreground text-sm text-center">{leaderboardData[2].name}</p>
            <p className="text-xs text-muted-foreground">{leaderboardData[2].winRate}% win rate</p>
            <div className="mt-2 h-16 w-full bg-gradient-to-t from-amber-600/20 to-transparent rounded-t-lg flex items-end justify-center pb-2">
              <span className="text-lg font-bold text-amber-500">3rd</span>
            </div>
          </div>
        </div>

        {/* Full Leaderboard Table */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/30">
                <tr>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-4">
                    Rank
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-4">
                    Trader
                  </th>
                  <th className="text-center text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-4">
                    Win Rate
                  </th>
                  <th className="text-center text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-4">
                    Subscribers
                  </th>
                  <th className="text-center text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-4">
                    Monthly Profit
                  </th>
                  <th className="text-right text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-4">
                    Earnings
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {leaderboardData.map((trader, index) => {
                  const rankChange = trader.previousRank - trader.rank;
                  return (
                    <tr
                      key={trader.username}
                      className={cn(
                        "hover:bg-muted/20 transition-colors animate-fade-in",
                        index < 3 && "bg-muted/10"
                      )}
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          {getRankIcon(trader.rank)}
                          {rankChange !== 0 && (
                            <span
                              className={cn(
                                "flex items-center text-xs",
                                rankChange > 0 ? "text-success" : "text-destructive"
                              )}
                            >
                              {rankChange > 0 ? (
                                <ChevronUp className="w-3 h-3" />
                              ) : (
                                <ChevronDown className="w-3 h-3" />
                              )}
                              {Math.abs(rankChange)}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div
                            className={cn(
                              "w-10 h-10 rounded-full p-0.5 bg-gradient-to-br",
                              tierStyles[trader.tier as keyof typeof tierStyles]
                            )}
                          >
                            <img
                              src={trader.avatar}
                              alt={trader.name}
                              className="w-full h-full rounded-full object-cover border border-card"
                            />
                          </div>
                          <div>
                            <p className="font-medium text-foreground">{trader.name}</p>
                            <p className="text-xs text-muted-foreground">@{trader.username}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-4 text-center">
                        <div className="inline-flex items-center gap-1 text-success">
                          <TrendingUp className="w-4 h-4" />
                          <span className="font-semibold">{trader.winRate}%</span>
                        </div>
                      </td>
                      <td className="px-5 py-4 text-center">
                        <div className="inline-flex items-center gap-1 text-muted-foreground">
                          <Users className="w-4 h-4" />
                          <span>{trader.subscribers.toLocaleString()}</span>
                        </div>
                      </td>
                      <td className="px-5 py-4 text-center">
                        <span className="font-medium text-primary">
                          +{(trader.monthlyProfit / 1000).toFixed(0)}k
                        </span>
                      </td>
                      <td className="px-5 py-4 text-right">
                        <span className="font-bold gradient-text">
                          ${trader.earnings.toLocaleString()}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
