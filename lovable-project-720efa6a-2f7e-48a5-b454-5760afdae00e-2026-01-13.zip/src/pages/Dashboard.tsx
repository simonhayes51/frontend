import { MainLayout } from "@/components/layout/MainLayout";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  Eye,
  Star,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3,
  Calendar,
} from "lucide-react";
import { cn } from "@/lib/utils";

const stats = [
  {
    label: "Total Earnings",
    value: "$2,847.50",
    change: "+12.5%",
    trend: "up",
    icon: DollarSign,
    color: "from-primary to-secondary",
  },
  {
    label: "Subscribers",
    value: "1,234",
    change: "+8.2%",
    trend: "up",
    icon: Users,
    color: "from-secondary to-accent",
  },
  {
    label: "Post Views",
    value: "45.2k",
    change: "+23.1%",
    trend: "up",
    icon: Eye,
    color: "from-accent to-primary",
  },
  {
    label: "Avg Rating",
    value: "4.8",
    change: "+0.2",
    trend: "up",
    icon: Star,
    color: "from-warning to-secondary",
  },
];

const recentTrades = [
  {
    id: "1",
    player: "Mbappé TOTY",
    type: "buy",
    buyPrice: 2800000,
    currentPrice: 3150000,
    profit: 350000,
    profitPercent: 12.5,
    date: "2 days ago",
    status: "open",
  },
  {
    id: "2",
    player: "Haaland",
    type: "sell",
    buyPrice: 1630000,
    currentPrice: 1950000,
    profit: 320000,
    profitPercent: 19.6,
    date: "3 days ago",
    status: "closed",
  },
  {
    id: "3",
    player: "Rodri TOTY",
    type: "buy",
    buyPrice: 3200000,
    currentPrice: 3050000,
    profit: -150000,
    profitPercent: -4.7,
    date: "5 days ago",
    status: "open",
  },
  {
    id: "4",
    player: "Vinícius Jr",
    type: "buy",
    buyPrice: 1800000,
    currentPrice: 2100000,
    profit: 300000,
    profitPercent: 16.7,
    date: "1 week ago",
    status: "closed",
  },
];

const earningsData = [
  { month: "Aug", amount: 1200 },
  { month: "Sep", amount: 1800 },
  { month: "Oct", amount: 1400 },
  { month: "Nov", amount: 2200 },
  { month: "Dec", amount: 2600 },
  { month: "Jan", amount: 2847 },
];

export default function Dashboard() {
  const maxEarning = Math.max(...earningsData.map((d) => d.amount));

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground font-display">Trader Dashboard</h1>
            <p className="text-muted-foreground">Track your performance and manage your trades</p>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 bg-card border border-border rounded-lg">
            <Calendar className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Last 30 days</span>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <div
              key={stat.label}
              className="bg-card border border-border rounded-xl p-5 animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start justify-between mb-3">
                <div
                  className={cn(
                    "w-10 h-10 rounded-lg flex items-center justify-center bg-gradient-to-br",
                    stat.color
                  )}
                >
                  <stat.icon className="w-5 h-5 text-primary-foreground" />
                </div>
                <div
                  className={cn(
                    "flex items-center gap-1 text-sm font-medium",
                    stat.trend === "up" ? "text-success" : "text-destructive"
                  )}
                >
                  {stat.trend === "up" ? (
                    <ArrowUpRight className="w-4 h-4" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4" />
                  )}
                  {stat.change}
                </div>
              </div>
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Earnings Chart */}
          <div className="lg:col-span-2 bg-card border border-border rounded-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-primary" />
                <h2 className="font-semibold text-foreground">Earnings Overview</h2>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold gradient-text">$2,847.50</p>
                <p className="text-xs text-muted-foreground">This month</p>
              </div>
            </div>
            
            {/* Simple Bar Chart */}
            <div className="flex items-end justify-between gap-2 h-48">
              {earningsData.map((data, index) => (
                <div key={data.month} className="flex-1 flex flex-col items-center gap-2">
                  <div
                    className={cn(
                      "w-full rounded-t-lg transition-all duration-500",
                      index === earningsData.length - 1
                        ? "bg-gradient-to-t from-primary to-secondary"
                        : "bg-muted hover:bg-muted/80"
                    )}
                    style={{
                      height: `${(data.amount / maxEarning) * 100}%`,
                      animationDelay: `${index * 100}ms`,
                    }}
                  />
                  <span className="text-xs text-muted-foreground">{data.month}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h2 className="font-semibold text-foreground mb-4">Performance Summary</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <span className="text-sm text-muted-foreground">Win Rate</span>
                <span className="font-semibold text-success">78%</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <span className="text-sm text-muted-foreground">Total Trades</span>
                <span className="font-semibold text-foreground">142</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <span className="text-sm text-muted-foreground">Avg Profit</span>
                <span className="font-semibold text-success">+14.2%</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <span className="text-sm text-muted-foreground">Best Trade</span>
                <span className="font-semibold text-secondary">+45.3%</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <span className="text-sm text-muted-foreground">Active Signals</span>
                <span className="font-semibold text-primary">12</span>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Trades */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="p-5 border-b border-border">
            <h2 className="font-semibold text-foreground">Recent Trades</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/30">
                <tr>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">
                    Player
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">
                    Type
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">
                    Buy Price
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">
                    Current
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">
                    Profit
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-5 py-3">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {recentTrades.map((trade) => (
                  <tr key={trade.id} className="hover:bg-muted/20 transition-colors">
                    <td className="px-5 py-4">
                      <span className="font-medium text-foreground">{trade.player}</span>
                    </td>
                    <td className="px-5 py-4">
                      <span
                        className={cn(
                          "inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium",
                          trade.type === "buy"
                            ? "bg-success/10 text-success"
                            : "bg-destructive/10 text-destructive"
                        )}
                      >
                        {trade.type === "buy" ? (
                          <TrendingUp className="w-3 h-3" />
                        ) : (
                          <TrendingDown className="w-3 h-3" />
                        )}
                        {trade.type.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-muted-foreground">
                      {(trade.buyPrice / 1000000).toFixed(2)}M
                    </td>
                    <td className="px-5 py-4 text-foreground">
                      {(trade.currentPrice / 1000000).toFixed(2)}M
                    </td>
                    <td className="px-5 py-4">
                      <div
                        className={cn(
                          "font-medium",
                          trade.profit > 0 ? "text-success" : "text-destructive"
                        )}
                      >
                        {trade.profit > 0 ? "+" : ""}
                        {(trade.profit / 1000).toFixed(0)}k ({trade.profitPercent > 0 ? "+" : ""}
                        {trade.profitPercent}%)
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <span
                        className={cn(
                          "px-2 py-1 rounded text-xs font-medium",
                          trade.status === "open"
                            ? "bg-primary/10 text-primary"
                            : "bg-muted text-muted-foreground"
                        )}
                      >
                        {trade.status.charAt(0).toUpperCase() + trade.status.slice(1)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
