import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { GradientButton } from "@/components/ui/GradientButton";
import { TraderBadges } from "@/components/trader/TraderBadges";
import { TraderRating } from "@/components/trader/TraderRating";
import { TradeSignalCard } from "@/components/trader/TradeSignalCard";
import { ReviewCard } from "@/components/trader/ReviewCard";
import { TraderStatsGrid } from "@/components/trader/TraderStatsGrid";
import { PerformanceChart } from "@/components/trader/PerformanceChart";
import { WriteReviewModal } from "@/components/trader/WriteReviewModal";
import { getTraderById, getReviewsByTraderId, activeSignals } from "@/data/tradersData";
import {
  ArrowLeft,
  CheckCircle2,
  Users,
  Calendar,
  Clock,
  MessageCircle,
  Heart,
  Bell,
  Share2,
  ExternalLink,
  Twitter,
  Youtube,
  PenSquare,
  Lock,
} from "lucide-react";
import { cn } from "@/lib/utils";

const tierColors = {
  bronze: "from-amber-700 to-amber-500",
  silver: "from-slate-400 to-slate-300",
  gold: "from-yellow-500 to-yellow-300",
  platinum: "from-cyan-400 to-cyan-200",
  diamond: "from-primary to-secondary",
};

export default function TraderProfile() {
  const { id } = useParams<{ id: string }>();
  const trader = getTraderById(id || "1");
  const reviews = getReviewsByTraderId(id || "1");
  const [activeTab, setActiveTab] = useState<"overview" | "signals" | "reviews">("overview");
  const [isFollowing, setIsFollowing] = useState(trader?.isFollowing || false);
  const [showReviewModal, setShowReviewModal] = useState(false);

  if (!trader) {
    return (
      <MainLayout>
        <div className="text-center py-20">
          <h1 className="text-2xl font-bold text-foreground mb-2">Trader Not Found</h1>
          <p className="text-muted-foreground mb-4">The trader you're looking for doesn't exist.</p>
          <Link to="/traders">
            <GradientButton>Browse Traders</GradientButton>
          </Link>
        </div>
      </MainLayout>
    );
  }

  const tabs = [
    { id: "overview", label: "Overview" },
    { id: "signals", label: "Signals", count: activeSignals.length },
    { id: "reviews", label: "Reviews", count: reviews.length },
  ];

  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto">
        {/* Back Button */}
        <Link
          to="/traders"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Traders</span>
        </Link>

        {/* Cover & Profile Header */}
        <div className="relative rounded-2xl overflow-hidden mb-6">
          {/* Cover Image */}
          <div className="h-48 sm:h-64 relative">
            <img
              src={trader.coverImage}
              alt="Cover"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
          </div>

          {/* Profile Info Overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6">
            <div className="flex flex-col sm:flex-row sm:items-end gap-4">
              {/* Avatar */}
              <div className={cn("relative rounded-full p-1 bg-gradient-to-br", tierColors[trader.tier])}>
                <img
                  src={trader.avatar}
                  alt={trader.name}
                  className="w-24 h-24 sm:w-32 sm:h-32 rounded-full object-cover border-4 border-background"
                />
                {trader.verified && (
                  <CheckCircle2 className="absolute bottom-1 right-1 w-6 h-6 text-primary fill-primary-foreground" />
                )}
              </div>

              {/* Name & Stats */}
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <h1 className="text-2xl sm:text-3xl font-bold text-foreground">{trader.name}</h1>
                  <span className={cn(
                    "text-xs font-bold uppercase px-2 py-1 rounded border",
                    trader.tier === "diamond" && "bg-gradient-to-r from-primary/20 to-secondary/20 text-primary border-primary/30",
                    trader.tier === "platinum" && "bg-cyan-500/20 text-cyan-300 border-cyan-300/30",
                    trader.tier === "gold" && "bg-yellow-500/20 text-yellow-400 border-yellow-400/30",
                    trader.tier === "silver" && "bg-slate-500/20 text-slate-300 border-slate-400/30",
                    trader.tier === "bronze" && "bg-amber-600/20 text-amber-400 border-amber-500/30"
                  )}>
                    {trader.tier}
                  </span>
                </div>
                <p className="text-muted-foreground mb-2">@{trader.username}</p>
                <TraderBadges badges={trader.badges} size="sm" />
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setIsFollowing(!isFollowing)}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all",
                    isFollowing
                      ? "bg-muted text-foreground"
                      : "bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground"
                  )}
                >
                  <Heart className={cn("w-4 h-4", isFollowing && "fill-current text-destructive")} />
                  {isFollowing ? "Following" : "Follow"}
                </button>
                {trader.isSubscribed ? (
                  <GradientButton variant="ghost">
                    <Bell className="w-4 h-4 mr-2" />
                    Subscribed
                  </GradientButton>
                ) : (
                  <GradientButton>
                    ${trader.subscriptionPrice}/mo
                  </GradientButton>
                )}
                <button className="p-2 bg-muted rounded-lg text-muted-foreground hover:text-foreground transition-colors">
                  <Share2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Stats Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-2xl font-bold gradient-text">{trader.subscribers.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground">Subscribers</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <TraderRating rating={trader.rating} totalReviews={trader.totalReviews} size="sm" />
          </div>
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-success">{trader.winRate}%</p>
            <p className="text-xs text-muted-foreground">Win Rate</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-secondary">{trader.stats.streak}</p>
            <p className="text-xs text-muted-foreground">Win Streak</p>
          </div>
        </div>

        {/* Bio & Info */}
        <div className="bg-card border border-border rounded-xl p-4 mb-6">
          <p className="text-muted-foreground mb-4">{trader.bio}</p>
          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4" />
              <span>Joined {new Date(trader.joinedAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4" />
              <span>Active {trader.lastActive}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Users className="w-4 h-4" />
              <span>{trader.following} following</span>
            </div>
          </div>
          
          {/* Specialties */}
          <div className="flex flex-wrap gap-2 mt-4">
            {trader.specialties.map((specialty) => (
              <span
                key={specialty}
                className="px-3 py-1 bg-muted text-muted-foreground rounded-full text-xs"
              >
                {specialty}
              </span>
            ))}
          </div>

          {/* Social Links */}
          {trader.socialLinks && (
            <div className="flex gap-3 mt-4 pt-4 border-t border-border">
              {trader.socialLinks.twitter && (
                <a href={`https://twitter.com/${trader.socialLinks.twitter}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors">
                  <Twitter className="w-4 h-4" />
                  <span>@{trader.socialLinks.twitter}</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
              {trader.socialLinks.youtube && (
                <a href={`https://youtube.com/@${trader.socialLinks.youtube}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-destructive transition-colors">
                  <Youtube className="w-4 h-4" />
                  <span>{trader.socialLinks.youtube}</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
              {trader.socialLinks.discord && (
                <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <MessageCircle className="w-4 h-4" />
                  <span>{trader.socialLinks.discord}</span>
                </span>
              )}
            </div>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-card border border-border rounded-xl p-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg font-medium transition-all",
                activeTab === tab.id
                  ? "bg-gradient-to-r from-primary to-secondary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {tab.label}
              {tab.count !== undefined && (
                <span className={cn(
                  "text-xs px-1.5 py-0.5 rounded-full",
                  activeTab === tab.id ? "bg-white/20" : "bg-muted"
                )}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            <TraderStatsGrid stats={trader.stats} winRate={trader.winRate} />
            <PerformanceChart monthlyReturns={trader.stats.monthlyReturns} />
            
            {/* Best Trade Highlight */}
            <div className="bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/30 rounded-xl p-4">
              <h3 className="font-semibold text-foreground mb-2">🏆 Best Trade</h3>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-lg font-bold text-foreground">{trader.stats.bestTrade.player}</p>
                  <p className="text-sm text-muted-foreground">{new Date(trader.stats.bestTrade.date).toLocaleDateString()}</p>
                </div>
                <p className="text-2xl font-bold text-success">+{trader.stats.bestTrade.profit.toLocaleString()}</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "signals" && (
          <div className="space-y-4">
            {!trader.isSubscribed && (
              <div className="bg-card border border-border rounded-xl p-6 text-center">
                <Lock className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <h3 className="text-lg font-semibold text-foreground mb-2">Premium Signals</h3>
                <p className="text-muted-foreground mb-4">Subscribe to access {trader.name}'s real-time trading signals</p>
                <GradientButton>${trader.subscriptionPrice}/mo - Subscribe Now</GradientButton>
              </div>
            )}
            
            {/* Show preview signals */}
            <div className={cn(!trader.isSubscribed && "opacity-50 pointer-events-none")}>
              <div className="grid gap-4">
                {activeSignals.map((signal) => (
                  <TradeSignalCard key={signal.id} signal={signal} />
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === "reviews" && (
          <div className="space-y-4">
            {/* Write Review Button */}
            <div className="flex justify-between items-center">
              <h3 className="font-semibold text-foreground">
                {reviews.length} Reviews
              </h3>
              <GradientButton size="sm" onClick={() => setShowReviewModal(true)}>
                <PenSquare className="w-4 h-4 mr-2" />
                Write a Review
              </GradientButton>
            </div>

            {/* Reviews List */}
            <div className="space-y-3">
              {reviews.map((review) => (
                <ReviewCard key={review.id} review={review} />
              ))}
            </div>

            {reviews.length === 0 && (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No reviews yet. Be the first to review!</p>
              </div>
            )}
          </div>
        )}

        {/* Review Modal */}
        {showReviewModal && (
          <WriteReviewModal
            traderName={trader.name}
            onClose={() => setShowReviewModal(false)}
            onSubmit={(rating, comment) => {
              console.log("Review submitted:", { rating, comment });
              // In a real app, this would save to the database
            }}
          />
        )}
      </div>
    </MainLayout>
  );
}
