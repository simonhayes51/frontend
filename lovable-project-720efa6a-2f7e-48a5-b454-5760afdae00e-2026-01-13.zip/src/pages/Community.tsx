import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { GradientButton } from "@/components/ui/GradientButton";
import {
  Upload,
  ThumbsUp,
  Eye,
  MessageCircle,
  Download,
  Filter,
  Plus,
  Gamepad2,
  BookOpen,
  Lightbulb,
  Trophy,
} from "lucide-react";
import { cn } from "@/lib/utils";

const categories = [
  { id: "all", label: "All", icon: null },
  { id: "tactics", label: "Tactics", icon: Gamepad2 },
  { id: "guides", label: "Guides", icon: BookOpen },
  { id: "tips", label: "Tips", icon: Lightbulb },
  { id: "reviews", label: "Reviews", icon: Trophy },
];

const communityPosts = [
  {
    id: "1",
    title: "Ultimate 4-3-2-1 Formation Guide for Weekend League",
    description: "Complete breakdown of the most effective formation in FC26. Custom tactics, player instructions, and in-game adjustments included.",
    category: "tactics",
    author: {
      name: "TacticsGuru",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop",
    },
    likes: 1247,
    views: 15600,
    comments: 234,
    downloads: 892,
    image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=800&h=400&fit=crop",
    featured: true,
  },
  {
    id: "2",
    title: "How to Invest in TOTW Cards - Beginner to Pro",
    description: "Learn the patterns, timing, and strategies to profit from Team of the Week investments consistently.",
    category: "guides",
    author: {
      name: "FC_Investor",
      avatar: "https://images.unsplash.com/photo-1599566150163-29194dcabd36?w=100&h=100&fit=crop",
    },
    likes: 856,
    views: 9800,
    comments: 156,
    downloads: 445,
    image: "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=800&h=400&fit=crop",
    featured: true,
  },
  {
    id: "3",
    title: "Silver Stars Hidden Gems - January 2026",
    description: "The best silver players that can compete with gold cards. Perfect for Silver Lounge and objectives.",
    category: "reviews",
    author: {
      name: "BudgetBeast",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    },
    likes: 523,
    views: 6200,
    comments: 89,
    downloads: 234,
    image: "https://images.unsplash.com/photo-1518604666860-9ed391f76460?w=800&h=400&fit=crop",
    featured: false,
  },
  {
    id: "4",
    title: "5 Skill Moves You NEED to Master",
    description: "From ball roll to elastico - these moves will elevate your gameplay and help you beat any defender.",
    category: "tips",
    author: {
      name: "SkillsKing",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    },
    likes: 1834,
    views: 21000,
    comments: 345,
    downloads: 1256,
    image: "https://images.unsplash.com/photo-1431324155629-1a6deb1dec8d?w=800&h=400&fit=crop",
    featured: true,
  },
  {
    id: "5",
    title: "Defending Meta Explained - How to Stop 442",
    description: "The 442 is everywhere this year. Here's how to set up your tactics to counter it effectively.",
    category: "tactics",
    author: {
      name: "DefenseMaster",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    },
    likes: 678,
    views: 8400,
    comments: 123,
    downloads: 389,
    image: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=800&h=400&fit=crop",
    featured: false,
  },
  {
    id: "6",
    title: "Complete SBC Investment Strategy",
    description: "When to buy, when to sell, and which leagues to focus on for maximum profit from Squad Building Challenges.",
    category: "guides",
    author: {
      name: "SBC_Expert",
      avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop",
    },
    likes: 945,
    views: 11200,
    comments: 178,
    downloads: 567,
    image: "https://images.unsplash.com/photo-1560272564-c83b66b1ad12?w=800&h=400&fit=crop",
    featured: false,
  },
];

const categoryColors = {
  tactics: "bg-primary/20 text-primary border-primary/30",
  guides: "bg-secondary/20 text-secondary border-secondary/30",
  tips: "bg-warning/20 text-warning border-warning/30",
  reviews: "bg-accent/20 text-accent border-accent/30",
};

export default function Community() {
  const [activeCategory, setActiveCategory] = useState("all");

  const filteredPosts =
    activeCategory === "all"
      ? communityPosts
      : communityPosts.filter((post) => post.category === activeCategory);

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground font-display">Community Hub</h1>
            <p className="text-muted-foreground">
              Share tactics, guides, and tips with the community
            </p>
          </div>
          <GradientButton>
            <Plus className="w-4 h-4" />
            Upload Content
          </GradientButton>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap items-center gap-2">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                activeCategory === category.id
                  ? "bg-gradient-to-r from-primary to-secondary text-primary-foreground"
                  : "bg-card border border-border text-muted-foreground hover:text-foreground hover:border-primary/50"
              )}
            >
              {category.icon && <category.icon className="w-4 h-4" />}
              {category.label}
            </button>
          ))}
        </div>

        {/* Featured Section */}
        {activeCategory === "all" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredPosts
              .filter((p) => p.featured)
              .slice(0, 2)
              .map((post, index) => (
                <div
                  key={post.id}
                  className="group relative bg-card border border-border rounded-xl overflow-hidden animate-fade-in"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent" />
                    <div className="absolute top-3 left-3">
                      <span
                        className={cn(
                          "text-xs font-bold uppercase px-2 py-1 rounded border",
                          categoryColors[post.category as keyof typeof categoryColors]
                        )}
                      >
                        {post.category}
                      </span>
                    </div>
                    <div className="absolute top-3 right-3">
                      <span className="text-xs font-bold uppercase px-2 py-1 rounded bg-secondary/20 text-secondary border border-secondary/30">
                        Featured
                      </span>
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="font-semibold text-lg text-foreground mb-2 group-hover:text-primary transition-colors">
                      {post.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                      {post.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <img
                          src={post.author.avatar}
                          alt={post.author.name}
                          className="w-6 h-6 rounded-full"
                        />
                        <span className="text-sm text-muted-foreground">
                          @{post.author.name}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <ThumbsUp className="w-3 h-3" />
                          {post.likes}
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="w-3 h-3" />
                          {(post.views / 1000).toFixed(1)}k
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        )}

        {/* All Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {(activeCategory === "all" ? filteredPosts.filter((p) => !p.featured) : filteredPosts).map(
            (post, index) => (
              <div
                key={post.id}
                className="group bg-card border border-border rounded-xl overflow-hidden hover:border-primary/50 transition-all animate-fade-in"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="relative h-36 overflow-hidden">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute top-2 left-2">
                    <span
                      className={cn(
                        "text-[10px] font-bold uppercase px-1.5 py-0.5 rounded border",
                        categoryColors[post.category as keyof typeof categoryColors]
                      )}
                    >
                      {post.category}
                    </span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-medium text-foreground mb-1 line-clamp-2 group-hover:text-primary transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                    {post.description}
                  </p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>by @{post.author.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="flex items-center gap-1">
                        <ThumbsUp className="w-3 h-3" />
                        {post.likes}
                      </span>
                      <span className="flex items-center gap-1">
                        <Download className="w-3 h-3" />
                        {post.downloads}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )
          )}
        </div>
      </div>
    </MainLayout>
  );
}
