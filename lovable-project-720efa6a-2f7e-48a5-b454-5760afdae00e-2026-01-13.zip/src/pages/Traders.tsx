import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { TraderCard } from "@/components/feed/TraderCard";
import { Search, Filter, Trophy, TrendingUp, Users, Star } from "lucide-react";
import { cn } from "@/lib/utils";

const allTraders = [
  {
    id: "1",
    name: "CoinMaster_FC",
    username: "coinmaster",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop",
    verified: true,
    rating: 4.9,
    subscribers: 12500,
    winRate: 78,
    tier: "diamond" as const,
    subscriptionPrice: 9.99,
  },
  {
    id: "2",
    name: "FC_Trader_Pro",
    username: "traderpro",
    avatar: "https://images.unsplash.com/photo-1599566150163-29194dcabd36?w=100&h=100&fit=crop",
    verified: true,
    rating: 4.7,
    subscribers: 8200,
    winRate: 72,
    tier: "platinum" as const,
    subscriptionPrice: 7.99,
  },
  {
    id: "3",
    name: "MarketKing",
    username: "marketking",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    verified: false,
    rating: 4.5,
    subscribers: 5600,
    winRate: 68,
    tier: "gold" as const,
    subscriptionPrice: 4.99,
  },
  {
    id: "4",
    name: "TradeMaster",
    username: "trademaster",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    verified: true,
    rating: 4.8,
    subscribers: 9800,
    winRate: 75,
    tier: "diamond" as const,
    subscriptionPrice: 12.99,
    isSubscribed: true,
  },
  {
    id: "5",
    name: "ProfitHunter",
    username: "profithunter",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    verified: true,
    rating: 4.6,
    subscribers: 6700,
    winRate: 71,
    tier: "platinum" as const,
    subscriptionPrice: 6.99,
  },
  {
    id: "6",
    name: "FC_Wizard",
    username: "fcwizard",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop",
    verified: false,
    rating: 4.3,
    subscribers: 3400,
    winRate: 65,
    tier: "silver" as const,
    subscriptionPrice: 2.99,
  },
  {
    id: "7",
    name: "CoinCollector",
    username: "coincollector",
    avatar: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=100&h=100&fit=crop",
    verified: true,
    rating: 4.4,
    subscribers: 4200,
    winRate: 67,
    tier: "gold" as const,
    subscriptionPrice: 5.99,
  },
  {
    id: "8",
    name: "BudgetBeast",
    username: "budgetbeast",
    avatar: "https://images.unsplash.com/photo-1463453091185-61582044d556?w=100&h=100&fit=crop",
    verified: false,
    rating: 4.1,
    subscribers: 2100,
    winRate: 62,
    tier: "bronze" as const,
    subscriptionPrice: 1.99,
  },
];

const filters = [
  { id: "all", label: "All", icon: Users },
  { id: "diamond", label: "Diamond", icon: Trophy },
  { id: "trending", label: "Trending", icon: TrendingUp },
  { id: "top-rated", label: "Top Rated", icon: Star },
];

export default function Traders() {
  const [activeFilter, setActiveFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredTraders = allTraders.filter((trader) => {
    if (searchQuery) {
      return (
        trader.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        trader.username.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    if (activeFilter === "diamond") return trader.tier === "diamond";
    if (activeFilter === "trending") return trader.subscribers > 5000;
    if (activeFilter === "top-rated") return trader.rating >= 4.5;
    return true;
  });

  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground font-display">Discover Traders</h1>
            <p className="text-muted-foreground">Find the best FC26 traders and subscribe to their signals</p>
          </div>
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search traders..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-card border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
            />
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {filters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                activeFilter === filter.id
                  ? "bg-gradient-to-r from-primary to-secondary text-primary-foreground"
                  : "bg-card border border-border text-muted-foreground hover:text-foreground hover:border-primary/50"
              )}
            >
              <filter.icon className="w-4 h-4" />
              {filter.label}
            </button>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-2xl font-bold gradient-text">{allTraders.length}</p>
            <p className="text-sm text-muted-foreground">Active Traders</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-success">71%</p>
            <p className="text-sm text-muted-foreground">Avg Win Rate</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-secondary">45.2k</p>
            <p className="text-sm text-muted-foreground">Subscribers</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-warning">4.6</p>
            <p className="text-sm text-muted-foreground">Avg Rating</p>
          </div>
        </div>

        {/* Traders Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredTraders.map((trader, index) => (
            <div
              key={trader.id}
              className="animate-fade-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <TraderCard trader={trader} />
            </div>
          ))}
        </div>

        {filteredTraders.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No traders found matching your criteria</p>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
