import { TrendingUp, TrendingDown, Minus, Clock, CheckCircle2, XCircle, Timer } from "lucide-react";
import { cn } from "@/lib/utils";
import { TradeSignal } from "@/types/trader";
import { formatDistanceToNow } from "date-fns";

interface TradeSignalCardProps {
  signal: TradeSignal;
  compact?: boolean;
}

const typeConfig = {
  buy: { icon: TrendingUp, color: "text-success", bg: "bg-success/10", label: "BUY" },
  sell: { icon: TrendingDown, color: "text-destructive", bg: "bg-destructive/10", label: "SELL" },
  hold: { icon: Minus, color: "text-warning", bg: "bg-warning/10", label: "HOLD" },
};

const statusConfig = {
  active: { icon: Timer, color: "text-primary", label: "Active" },
  hit: { icon: CheckCircle2, color: "text-success", label: "Target Hit" },
  missed: { icon: XCircle, color: "text-destructive", label: "Missed" },
  expired: { icon: Clock, color: "text-muted-foreground", label: "Expired" },
};

export function TradeSignalCard({ signal, compact = false }: TradeSignalCardProps) {
  const TypeIcon = typeConfig[signal.type].icon;
  const StatusIcon = statusConfig[signal.status].icon;
  const priceChange = signal.targetPrice - signal.currentPrice;
  const percentChange = ((priceChange / signal.currentPrice) * 100).toFixed(1);

  if (compact) {
    return (
      <div className="flex items-center gap-3 p-3 bg-card border border-border rounded-lg hover:border-primary/50 transition-all">
        <div className={cn("p-2 rounded-lg", typeConfig[signal.type].bg)}>
          <TypeIcon className={cn("w-4 h-4", typeConfig[signal.type].color)} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-medium text-foreground truncate">{signal.player}</p>
          <p className="text-xs text-muted-foreground">
            {signal.currentPrice.toLocaleString()} → {signal.targetPrice.toLocaleString()}
          </p>
        </div>
        <div className={cn("text-xs font-medium", signal.type === "sell" ? "text-destructive" : "text-success")}>
          {signal.type === "sell" ? "" : "+"}{percentChange}%
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-xl p-4 hover:border-primary/50 transition-all">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <img
            src={signal.playerImage}
            alt={signal.player}
            className="w-12 h-12 rounded-lg object-cover"
          />
          <div>
            <h4 className="font-semibold text-foreground">{signal.player}</h4>
            <div className="flex items-center gap-2 mt-0.5">
              <span className={cn(
                "text-[10px] font-bold px-2 py-0.5 rounded",
                typeConfig[signal.type].bg,
                typeConfig[signal.type].color
              )}>
                {typeConfig[signal.type].label}
              </span>
              <span className="text-xs text-muted-foreground">
                {formatDistanceToNow(new Date(signal.createdAt), { addSuffix: true })}
              </span>
            </div>
          </div>
        </div>
        <div className={cn("flex items-center gap-1 text-xs font-medium", statusConfig[signal.status].color)}>
          <StatusIcon className="w-3 h-3" />
          {statusConfig[signal.status].label}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="text-center p-2 bg-muted/50 rounded-lg">
          <p className="text-xs text-muted-foreground mb-0.5">Current</p>
          <p className="font-semibold text-foreground">{signal.currentPrice.toLocaleString()}</p>
        </div>
        <div className="text-center p-2 bg-muted/50 rounded-lg">
          <p className="text-xs text-muted-foreground mb-0.5">Target</p>
          <p className="font-semibold text-foreground">{signal.targetPrice.toLocaleString()}</p>
        </div>
        <div className="text-center p-2 bg-muted/50 rounded-lg">
          <p className="text-xs text-muted-foreground mb-0.5">Confidence</p>
          <p className={cn("font-semibold", signal.confidence >= 80 ? "text-success" : signal.confidence >= 60 ? "text-warning" : "text-destructive")}>
            {signal.confidence}%
          </p>
        </div>
      </div>

      {signal.status === "hit" && signal.profit && (
        <div className="mt-3 p-2 bg-success/10 border border-success/30 rounded-lg text-center">
          <span className="text-success font-semibold">+{signal.profit.toLocaleString()} coins profit!</span>
        </div>
      )}

      <div className="mt-3 w-full bg-muted rounded-full h-1.5 overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-primary to-secondary rounded-full transition-all"
          style={{ width: `${signal.confidence}%` }}
        />
      </div>
    </div>
  );
}
