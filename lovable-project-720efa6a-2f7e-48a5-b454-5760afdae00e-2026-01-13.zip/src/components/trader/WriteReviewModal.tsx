import { useState } from "react";
import { X, Send } from "lucide-react";
import { GradientButton } from "@/components/ui/GradientButton";
import { TraderRating } from "./TraderRating";
import { cn } from "@/lib/utils";

interface WriteReviewModalProps {
  traderName: string;
  onClose: () => void;
  onSubmit: (rating: number, comment: string) => void;
}

export function WriteReviewModal({ traderName, onClose, onSubmit }: WriteReviewModalProps) {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");

  const handleSubmit = () => {
    if (rating > 0 && comment.trim()) {
      onSubmit(rating, comment);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-card border border-border rounded-2xl p-6 w-full max-w-md animate-scale-in">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-xl font-bold text-foreground mb-1">Write a Review</h2>
        <p className="text-sm text-muted-foreground mb-6">
          Share your experience with {traderName}
        </p>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Your Rating
            </label>
            <TraderRating
              rating={rating}
              size="lg"
              showCount={false}
              interactive
              onRatingChange={setRating}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Your Review
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Tell others about your experience..."
              rows={4}
              className="w-full px-4 py-3 bg-muted border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
            />
          </div>

          <div className="flex gap-3 pt-2">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-2.5 bg-muted text-foreground rounded-lg font-medium hover:bg-muted/80 transition-colors"
            >
              Cancel
            </button>
            <GradientButton
              onClick={handleSubmit}
              disabled={rating === 0 || !comment.trim()}
              className={cn(
                "flex-1",
                (rating === 0 || !comment.trim()) && "opacity-50 cursor-not-allowed"
              )}
            >
              <Send className="w-4 h-4 mr-2" />
              Submit Review
            </GradientButton>
          </div>
        </div>
      </div>
    </div>
  );
}
