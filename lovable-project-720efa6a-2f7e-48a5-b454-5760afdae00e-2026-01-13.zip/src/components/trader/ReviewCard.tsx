import { ThumbsUp } from "lucide-react";
import { TraderRating } from "./TraderRating";
import { TraderReview } from "@/types/trader";
import { formatDistanceToNow } from "date-fns";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface ReviewCardProps {
  review: TraderReview;
}

export function ReviewCard({ review }: ReviewCardProps) {
  const [helpful, setHelpful] = useState(review.helpful);
  const [hasVoted, setHasVoted] = useState(false);

  const handleHelpful = () => {
    if (!hasVoted) {
      setHelpful((prev) => prev + 1);
      setHasVoted(true);
    }
  };

  return (
    <div className="bg-card border border-border rounded-xl p-4 hover:border-primary/20 transition-all">
      <div className="flex items-start gap-3">
        <img
          src={review.userAvatar}
          alt={review.userName}
          className="w-10 h-10 rounded-full object-cover"
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h4 className="font-medium text-foreground">{review.userName}</h4>
              <p className="text-xs text-muted-foreground">
                {formatDistanceToNow(new Date(review.createdAt), { addSuffix: true })}
              </p>
            </div>
            <TraderRating rating={review.rating} size="sm" showCount={false} />
          </div>
          
          <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
            {review.comment}
          </p>

          <button
            onClick={handleHelpful}
            disabled={hasVoted}
            className={cn(
              "mt-3 flex items-center gap-1.5 text-xs transition-all",
              hasVoted
                ? "text-primary cursor-default"
                : "text-muted-foreground hover:text-primary"
            )}
          >
            <ThumbsUp className={cn("w-3.5 h-3.5", hasVoted && "fill-primary")} />
            <span>Helpful ({helpful})</span>
          </button>
        </div>
      </div>
    </div>
  );
}
