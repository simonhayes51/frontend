import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface TraderRatingProps {
  rating: number;
  totalReviews?: number;
  size?: "sm" | "md" | "lg";
  showCount?: boolean;
  interactive?: boolean;
  onRatingChange?: (rating: number) => void;
}

export function TraderRating({
  rating,
  totalReviews,
  size = "md",
  showCount = true,
  interactive = false,
  onRatingChange,
}: TraderRatingProps) {
  const sizeClasses = {
    sm: "w-3 h-3",
    md: "w-4 h-4",
    lg: "w-5 h-5",
  };

  const textClasses = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
  };

  const handleStarClick = (starIndex: number) => {
    if (interactive && onRatingChange) {
      onRatingChange(starIndex + 1);
    }
  };

  return (
    <div className="flex items-center gap-1.5">
      <div className="flex items-center gap-0.5">
        {[...Array(5)].map((_, i) => {
          const filled = i < Math.floor(rating);
          const partial = i === Math.floor(rating) && rating % 1 > 0;
          
          return (
            <button
              key={i}
              onClick={() => handleStarClick(i)}
              disabled={!interactive}
              className={cn(
                "relative transition-transform",
                interactive && "hover:scale-110 cursor-pointer"
              )}
            >
              <Star
                className={cn(
                  sizeClasses[size],
                  filled || partial
                    ? "text-warning fill-warning"
                    : "text-muted-foreground/40"
                )}
              />
              {partial && (
                <div
                  className="absolute inset-0 overflow-hidden"
                  style={{ width: `${(rating % 1) * 100}%` }}
                >
                  <Star
                    className={cn(sizeClasses[size], "text-warning fill-warning")}
                  />
                </div>
              )}
            </button>
          );
        })}
      </div>
      <span className={cn("font-semibold text-foreground", textClasses[size])}>
        {rating.toFixed(1)}
      </span>
      {showCount && totalReviews !== undefined && (
        <span className={cn("text-muted-foreground", textClasses[size])}>
          ({totalReviews.toLocaleString()} reviews)
        </span>
      )}
    </div>
  );
}
