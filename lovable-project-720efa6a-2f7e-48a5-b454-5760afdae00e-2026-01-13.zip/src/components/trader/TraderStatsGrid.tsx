import { TrendingUp, Trophy, Flame, Users, DollarSign, Target, BarChart3, Zap } from "lucide-react";
import { TraderStats } from "@/types/trader";
import { cn } from "@/lib/utils";

interface TraderStatsGridProps {
  stats: TraderStats;
  winRate: number;
}

export function TraderStatsGrid({ stats, winRate }: TraderStatsGridProps) {
  const statItems = [
    {
      label: "Win Rate",
      value: `${winRate}%`,
      icon: Target,
      color: "text-success",
      bg: "bg-success/10",
    },
    {
      label: "Total Trades",
      value: stats.totalTrades.toLocaleString(),
      icon: BarChart3,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      label: "Current Streak",
      value: `${stats.streak} wins`,
      icon: Flame,
      color: "text-destructive",
      bg: "bg-destructive/10",
    },
    {
      label: "Avg Profit",
      value: `${(stats.averageProfit / 1000).toFixed(1)}k`,
      icon: TrendingUp,
      color: "text-success",
      bg: "bg-success/10",
    },
    {
      label: "Total Earnings",
      value: `${(stats.totalEarnings / 1000000).toFixed(1)}M`,
      icon: DollarSign,
      color: "text-warning",
      bg: "bg-warning/10",
    },
    {
      label: "Successful",
      value: stats.successfulTrades.toLocaleString(),
      icon: Trophy,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      label: "Sub Growth",
      value: `+${stats.subscriberGrowth}%`,
      icon: Users,
      color: "text-secondary",
      bg: "bg-secondary/10",
    },
    {
      label: "Best Trade",
      value: `+${(stats.bestTrade.profit / 1000000).toFixed(1)}M`,
      icon: Zap,
      color: "text-warning",
      bg: "bg-warning/10",
    },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      {statItems.map((item) => (
        <div
          key={item.label}
          className="bg-card border border-border rounded-xl p-4 hover:border-primary/30 transition-all group"
        >
          <div className="flex items-center gap-2 mb-2">
            <div className={cn("p-1.5 rounded-lg", item.bg)}>
              <item.icon className={cn("w-4 h-4", item.color)} />
            </div>
          </div>
          <p className={cn("text-xl font-bold", item.color)}>{item.value}</p>
          <p className="text-xs text-muted-foreground mt-0.5">{item.label}</p>
        </div>
      ))}
    </div>
  );
}
