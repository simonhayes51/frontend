import { CheckCircle2, Star, Flame, GraduationCap, Gem, Rocket, LineChart, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { TraderBadge } from "@/types/trader";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  CheckCircle2,
  Star,
  Flame,
  GraduationCap,
  Gem,
  Rocket,
  LineChart,
  Users,
};

const colorMap: Record<string, string> = {
  primary: "bg-primary/20 text-primary border-primary/30",
  secondary: "bg-secondary/20 text-secondary border-secondary/30",
  warning: "bg-warning/20 text-warning border-warning/30",
  destructive: "bg-destructive/20 text-destructive border-destructive/30",
  success: "bg-success/20 text-success border-success/30",
  accent: "bg-accent/20 text-accent border-accent/30",
};

interface TraderBadgesProps {
  badges: TraderBadge[];
  size?: "sm" | "md" | "lg";
  showLabels?: boolean;
}

export function TraderBadges({ badges, size = "md", showLabels = false }: TraderBadgesProps) {
  const sizeClasses = {
    sm: "w-4 h-4",
    md: "w-5 h-5",
    lg: "w-6 h-6",
  };

  const containerClasses = {
    sm: "p-1",
    md: "p-1.5",
    lg: "p-2",
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      {badges.map((badge) => {
        const IconComponent = iconMap[badge.icon] || Star;
        return (
          <div
            key={badge.id}
            className={cn(
              "flex items-center gap-1.5 rounded-full border transition-all hover:scale-105 cursor-help",
              colorMap[badge.color] || colorMap.primary,
              containerClasses[size],
              showLabels && "px-2.5 py-1"
            )}
            title={badge.description}
          >
            <IconComponent className={sizeClasses[size]} />
            {showLabels && (
              <span className="text-xs font-medium">{badge.name}</span>
            )}
          </div>
        );
      })}
    </div>
  );
}
