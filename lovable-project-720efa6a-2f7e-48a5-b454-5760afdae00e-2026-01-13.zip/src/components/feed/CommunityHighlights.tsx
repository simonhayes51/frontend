import { Upload, ThumbsUp, Eye, ChevronRight } from "lucide-react";

const communityPosts = [
  {
    id: "1",
    title: "Best 4-3-2-1 Formation for Weekend League",
    author: "TacticsGuru",
    likes: 342,
    views: 2100,
    type: "tactic",
  },
  {
    id: "2",
    title: "Investing in TOTW Cards - Complete Guide",
    author: "FC_Investor",
    likes: 256,
    views: 1800,
    type: "guide",
  },
  {
    id: "3",
    title: "Silver Stars Hidden Gems",
    author: "BudgetBeast",
    likes: 189,
    views: 1200,
    type: "review",
  },
];

const typeColors = {
  tactic: "bg-primary/20 text-primary border-primary/30",
  guide: "bg-secondary/20 text-secondary border-secondary/30",
  review: "bg-accent/20 text-accent border-accent/30",
};

export function CommunityHighlights() {
  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Upload className="w-5 h-5 text-accent" />
          <h2 className="font-semibold text-foreground">Community</h2>
        </div>
        <button className="flex items-center gap-1 text-sm text-primary hover:underline">
          Browse
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-3">
        {communityPosts.map((post) => (
          <div
            key={post.id}
            className="p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer"
          >
            <div className="flex items-start gap-2 mb-2">
              <span
                className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded border ${
                  typeColors[post.type as keyof typeof typeColors]
                }`}
              >
                {post.type}
              </span>
            </div>
            <h3 className="text-sm font-medium text-foreground mb-1 line-clamp-2">
              {post.title}
            </h3>
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>by @{post.author}</span>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <ThumbsUp className="w-3 h-3" />
                  {post.likes}
                </span>
                <span className="flex items-center gap-1">
                  <Eye className="w-3 h-3" />
                  {post.views}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
