import { useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  Home,
  Users,
  Trophy,
  Upload,
  BarChart3,
  Settings,
  Bell,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Flame,
  Star,
  Wallet,
} from "lucide-react";
import { cn } from "@/lib/utils";
import logo from "@/assets/logo.png";

const mainNavItems = [
  { icon: Home, label: "Feed", path: "/" },
  { icon: Users, label: "Traders", path: "/traders" },
  { icon: Flame, label: "Trending", path: "/trending" },
  { icon: Upload, label: "Community", path: "/community" },
  { icon: Trophy, label: "Leaderboard", path: "/leaderboard" },
];

const userNavItems = [
  { icon: BarChart3, label: "Dashboard", path: "/dashboard" },
  { icon: Wallet, label: "Earnings", path: "/earnings" },
  { icon: Star, label: "Subscriptions", path: "/subscriptions" },
];

const bottomNavItems = [
  { icon: Bell, label: "Notifications", path: "/notifications" },
  { icon: Settings, label: "Settings", path: "/settings" },
];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  const NavItem = ({ item }: { item: typeof mainNavItems[0] }) => {
    const isActive = location.pathname === item.path;
    
    return (
      <NavLink
        to={item.path}
        className={cn(
          "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group relative",
          isActive
            ? "bg-gradient-to-r from-primary/20 to-secondary/10 text-primary"
            : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
        )}
      >
        {isActive && (
          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-gradient-to-b from-primary to-secondary rounded-r-full" />
        )}
        <item.icon className={cn("w-5 h-5 flex-shrink-0", isActive && "text-primary")} />
        {!collapsed && (
          <span className="font-medium text-sm">{item.label}</span>
        )}
      </NavLink>
    );
  };

  return (
    <aside
      className={cn(
        "h-screen bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300 sticky top-0",
        collapsed ? "w-16" : "w-64"
      )}
    >
      {/* Logo */}
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <img src={logo} alt="Transfer Traders" className="w-10 h-10 object-contain" />
          {!collapsed && (
            <div className="flex flex-col">
              <span className="font-display font-bold text-sm gradient-text">TRANSFER</span>
              <span className="font-display font-bold text-xs text-muted-foreground">TRADERS</span>
            </div>
          )}
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto scrollbar-thin">
        <div className="space-y-1">
          {mainNavItems.map((item) => (
            <NavItem key={item.path} item={item} />
          ))}
        </div>

        <div className="pt-4 mt-4 border-t border-sidebar-border space-y-1">
          {!collapsed && (
            <p className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
              Your Space
            </p>
          )}
          {userNavItems.map((item) => (
            <NavItem key={item.path} item={item} />
          ))}
        </div>
      </nav>

      {/* Bottom Navigation */}
      <div className="p-3 border-t border-sidebar-border space-y-1">
        {bottomNavItems.map((item) => (
          <NavItem key={item.path} item={item} />
        ))}
        
        <button className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all w-full">
          <LogOut className="w-5 h-5" />
          {!collapsed && <span className="font-medium text-sm">Log Out</span>}
        </button>
      </div>

      {/* Collapse Toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 w-6 h-6 bg-card border border-border rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
      >
        {collapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
      </button>
    </aside>
  );
}
